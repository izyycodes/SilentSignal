<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'Silent Signal'; ?></title>
    <link rel="icon" type="image/png" href="assets/images/logo.png">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/c835d6c14b.js" crossorigin="anonymous"></script>
    
    <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="assets/css/home-header.css">
    <link rel="stylesheet" href="assets/css/home-footer.css">
</head>
<body>
<header class="header">
    <div class="container">
            
            <input type="checkbox" id="sidebar-active">
            <label for="sidebar-active" class="open-sidebar-btn">
                <i class="ri-menu-line"></i>
            </label>
            
            <div class="links-container">
                <label for="sidebar-active" class="close-sidebar-btn">
                    <i class="ri-close-line"></i>
                </label>
                
                <div class="logo">
                    <img src="assets/images/logo.png" alt="Silent Signal Logo" class="logo-icon">
                    <span class="logo-text">Silent Signal.</span>
                </div>

                <ul class="nav-menu">
                <li><a href="<?= $isHome ? '#home' : 'index.php?action=home#home' ?>" class="nav-link">Home</a></li>
                <li><a href="<?= $isHome ? '#features' : 'index.php?action=home#features' ?>" class="nav-link">Features</a></li>
                <li><a href="<?= $isHome ? '#how-it-works' : 'index.php?action=home#how-it-works' ?>" class="nav-link">How It Works</a></li>
                <li><a href="<?= $isHome ? '#contact' : 'index.php?action=home#contact' ?>"" class="nav-link">Contact</a></li>
                </ul>
                
                <div class="nav-buttons">
                    <a href="index.php?action=login" class="btn btn-secondary">Login</a>
                    <a href="index.php?action=signup" class="btn btn-primary">Sign Up</a>
                </div>

            </div>
    </div>
</header>
</body>